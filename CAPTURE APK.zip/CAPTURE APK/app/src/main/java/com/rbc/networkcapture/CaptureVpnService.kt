package com.rbc.networkcapture

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.*
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class CaptureVpnService : VpnService() {
    companion object {
        const val START="com.rbc.networkcapture.START"
        const val STOP="com.rbc.networkcapture.STOP"
        const val ACTION_PACKET="com.rbc.networkcapture.PACKET"
        const val ACTION_STOPPED="com.rbc.networkcapture.STOPPED"
        private const val CHANNEL="rbc_capture"
    }
    private var tun: ParcelFileDescriptor?=null
    private val running=AtomicBoolean(false)
    private var total=0L; private var tcp=0L; private var udp=0L
    private var pcap: DataOutputStream?=null
    private var pcapFile: File?=null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if(intent?.action==STOP) { stopCapture(); return START_NOT_STICKY }
        if(intent?.action==START && running.compareAndSet(false,true)) {
            createChannel()
            val n=Notification.Builder(this,CHANNEL).setContentTitle("RBC Network Capture")
                .setContentText("Capturing packet headers — internet forwarding is disabled")
                .setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).build()
            startForeground(41,n)
            try {
                val dir=File(getExternalFilesDir(null),"output").apply { mkdirs() }
                pcapFile=File(dir,"rbc_${System.currentTimeMillis()}.pcap")
                pcap=DataOutputStream(BufferedOutputStream(FileOutputStream(pcapFile)))
                writePcapHeader(pcap!!)
                tun=Builder().setSession("RBC Network Capture")
                    .addAddress("10.77.0.1",32)
                    .addAddress("fd77::1",128)
                    .addRoute("0.0.0.0",0)
                    .addRoute("::",0)
                    .setMtu(1500).establish()
                val fd=tun ?: throw IOException("VPN interface could not be established")
                thread(name="RBC-Packet-Reader") { readLoop(fd) }
            } catch(e:Exception) {
                running.set(false); closeAll(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            }
        }
        return START_NOT_STICKY
    }
    private fun createChannel() {
        if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL,"RBC Capture",NotificationManager.IMPORTANCE_LOW))
    }
    private fun writePcapHeader(o:DataOutputStream) {
        // PCAP little-endian global header, LINKTYPE_RAW (101)
        o.write(byteArrayOf(0xd4.toByte(),0xc3.toByte(),0xb2.toByte(),0xa1.toByte()))
        writeLE16(o,2); writeLE16(o,4); writeLE32(o,0); writeLE32(o,0); writeLE32(o,65535); writeLE32(o,101)
    }
    private fun readLoop(fd:ParcelFileDescriptor) {
        val input=FileInputStream(fd.fileDescriptor); val buf=ByteArray(65535)
        try {
            while(running.get()) {
                val n=input.read(buf); if(n<=0) continue
                val packet=buf.copyOf(n); total++
                val info=parse(packet)
                if(info.proto=="TCP") tcp++ else if(info.proto=="UDP") udp++
                synchronized(this) { pcap?.let { out ->
                    val now=System.currentTimeMillis(); writeLE32(out,now/1000); writeLE32(out,(now%1000)*1000)
                    writeLE32(out,n.toLong()); writeLE32(out,n.toLong()); out.write(packet); out.flush()
                } }
                val i=Intent(ACTION_PACKET).setPackage(packageName)
                    .putExtra("line",String.format(Locale.US,"%tT  %-5s  %s:%d  →  %s:%d  %d B",Date(),info.proto,info.src,info.sport,info.dst,info.dport,n))
                    .putExtra("count",total).putExtra("tcp",tcp).putExtra("udp",udp)
                    .putExtra("file",pcapFile?.name)
                    .putExtra("hex", packet.take(256).joinToString(" ") { "%02X".format(it) })
                    .putExtra("src", info.src).putExtra("dst", info.dst)
                    .putExtra("proto", info.proto).putExtra("sport", info.sport).putExtra("dport", info.dport)
                    .putExtra("length", n)
                sendBroadcast(i)
            }
        } catch(_:Exception) { }
        finally { stopCapture() }
    }
    data class Packet(val proto:String,val src:String,val dst:String,val sport:Int,val dport:Int)
    private fun parse(b:ByteArray):Packet {
        try {
            val version=(b[0].toInt() ushr 4) and 15
            if(version==4 && b.size>=20) {
                val ihl=(b[0].toInt() and 15)*4; val proto=b[9].toInt() and 255
                val src=InetAddress.getByAddress(b.copyOfRange(12,16)).hostAddress ?: "?"
                val dst=InetAddress.getByAddress(b.copyOfRange(16,20)).hostAddress ?: "?"
                val p=if(proto==6)"TCP" else if(proto==17)"UDP" else "IP"
                val sp=if((p=="TCP"||p=="UDP")&&b.size>=ihl+4) u16(b,ihl) else 0
                val dp=if((p=="TCP"||p=="UDP")&&b.size>=ihl+4) u16(b,ihl+2) else 0
                return Packet(p,src,dst,sp,dp)
            }
            if(version==6 && b.size>=40) {
                val next=b[6].toInt() and 255
                val src=InetAddress.getByAddress(b.copyOfRange(8,24)).hostAddress ?: "?"
                val dst=InetAddress.getByAddress(b.copyOfRange(24,40)).hostAddress ?: "?"
                val p=if(next==6)"TCP" else if(next==17)"UDP" else "IPv6"
                val sp=if((p=="TCP"||p=="UDP")&&b.size>=44) u16(b,40) else 0
                val dp=if((p=="TCP"||p=="UDP")&&b.size>=44) u16(b,42) else 0
                return Packet(p,src,dst,sp,dp)
            }
        } catch(_:Exception) { }
        return Packet("OTHER","?","?",0,0)
    }
    private fun u16(b:ByteArray,i:Int)=((b[i].toInt() and 255) shl 8) or (b[i+1].toInt() and 255)
    private fun writeLE16(o:DataOutputStream,v:Int) { o.writeByte(v); o.writeByte(v ushr 8) }
    private fun writeLE32(o:DataOutputStream,v:Long) { o.writeByte(v.toInt()); o.writeByte((v ushr 8).toInt()); o.writeByte((v ushr 16).toInt()); o.writeByte((v ushr 24).toInt()) }
    @Synchronized private fun stopCapture() {
        if(!running.getAndSet(false)) return
        closeAll()
        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    private fun closeAll() {
        try { tun?.close() } catch(_:Exception) {}; tun=null
        try { synchronized(this) { pcap?.flush(); pcap?.close(); pcap=null } } catch(_:Exception) {}
    }
    override fun onDestroy() { running.set(false); closeAll(); super.onDestroy() }
}
