package com.rbc.networkcapture

import android.app.Activity
import android.content.*
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import java.util.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var list: LinearLayout
    private val rows = mutableListOf<PacketRow>()
    data class PacketRow(val summary:String, val proto:String, val src:String, val dst:String,
                         val sport:Int, val dport:Int, val length:Int, val hex:String)
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == CaptureVpnService.ACTION_PACKET) {
                val row=PacketRow(i.getStringExtra("line") ?: return,
                    i.getStringExtra("proto") ?: "IP", i.getStringExtra("src") ?: "?",
                    i.getStringExtra("dst") ?: "?", i.getIntExtra("sport",0),
                    i.getIntExtra("dport",0), i.getIntExtra("length",0),
                    i.getStringExtra("hex") ?: "")
                rows.add(0,row); if(rows.size>150) rows.removeAt(rows.lastIndex)
                renderRows()
                stats.text="PACKETS  ${i.getLongExtra("count",0)}     TCP  ${i.getLongExtra("tcp",0)}     UDP  ${i.getLongExtra("udp",0)}"
                status.text="● CAPTURING  •  ${i.getStringExtra("file") ?: "PCAP active"}"
            }
            if(i?.action==CaptureVpnService.ACTION_STOPPED) status.text="● CAPTURE STOPPED"
        }
    }
    private fun bg(color:Int,radius:Float=16f)=GradientDrawable().apply { setColor(color); cornerRadius=radius }
    private fun text(s:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD)
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val navy=Color.rgb(8,20,39); val blue=Color.rgb(25,105,230)
        val white=Color.WHITE; val pale=Color.rgb(229,239,253)
        val root=LinearLayout(this).apply { orientation=1; setPadding(18,24,18,14); setBackgroundColor(pale) }
        val header=LinearLayout(this).apply { orientation=1; setPadding(18,18,18,18); background=bg(navy,22f) }
        header.addView(text("RBC  /  NETWORK",12f,Color.rgb(120,177,255),true))
        header.addView(text("Capture",28f,white,true))
        header.addView(text("REAL-TIME TCP • UDP • PCAP ANALYZER",10f,Color.LTGRAY,true))
        status=text("● READY TO CAPTURE",13f,Color.rgb(65,205,151),true); status.setPadding(0,16,0,4); header.addView(status)
        root.addView(header)
        stats=text("PACKETS  0     TCP  0     UDP  0",13f,navy,true)
        stats.setPadding(4,18,4,14); root.addView(stats)
        val actions=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER; setPadding(0,0,0,12) }
        val start=Button(this).apply { text="START CAPTURE"; setTextColor(white); background=bg(blue,14f); setOnClickListener {
            val prep=VpnService.prepare(this@MainActivity)
            if(prep!=null) startActivityForResult(prep,7) else startCapture()
        } }
        val stop=Button(this).apply { text="STOP"; setTextColor(navy); background=bg(white,14f); setOnClickListener {
            startService(Intent(this@MainActivity,CaptureVpnService::class.java).setAction(CaptureVpnService.STOP))
        } }
        actions.addView(start,LinearLayout.LayoutParams(0,54,1f).apply { rightMargin=8 })
        actions.addView(stop,LinearLayout.LayoutParams(0,54,1f)); root.addView(actions)
        root.addView(text("LIVE PACKETS  ·  Tap a packet for details",14f,navy,true))
        val scroll=ScrollView(this).apply { isFillViewport=true }
        list=LinearLayout(this).apply { orientation=1 }
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val footer=text("PCAP files are saved in the app's output folder. Capture-only mode pauses internet while active.",10f,Color.DKGRAY)
        footer.setPadding(2,10,2,0); root.addView(footer)
        setContentView(root)
        val filter=IntentFilter().apply { addAction(CaptureVpnService.ACTION_PACKET); addAction(CaptureVpnService.ACTION_STOPPED) }
        if(android.os.Build.VERSION.SDK_INT>=33) registerReceiver(receiver,filter,Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver,filter)
    }
    private fun renderRows() {
        list.removeAllViews()
        rows.forEach { row ->
            val card=LinearLayout(this).apply { orientation=1; setPadding(13,12,13,12); background=bg(Color.WHITE,14f) }
            val top=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
            val tag=text(row.proto,11f,Color.rgb(20,93,204),true)
            top.addView(tag,LinearLayout.LayoutParams(0,-2,1f))
            top.addView(text("${row.length} B",11f,Color.DKGRAY,true))
            card.addView(top)
            card.addView(text("${row.src}:${row.sport}",12f,Color.rgb(22,34,52),true))
            card.addView(text("↓  ${row.dst}:${row.dport}",12f,Color.rgb(65,83,107)))
            card.setOnClickListener { showDetails(row) }
            val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=8; list.addView(card,lp)
        }
    }
    private fun showDetails(r:PacketRow) {
        val body="Protocol: ${r.proto}\nSource: ${r.src}:${r.sport}\nDestination: ${r.dst}:${r.dport}\nLength: ${r.length} bytes\n\nHEX (first 256 bytes):\n${r.hex}"
        android.app.AlertDialog.Builder(this).setTitle("Packet details").setMessage(body)
            .setPositiveButton("COPY HEX") { _,_-> val cm=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Packet HEX",r.hex)) }
            .setNegativeButton("CLOSE",null).show()
    }
    private fun startCapture() { startForegroundService(Intent(this,CaptureVpnService::class.java).setAction(CaptureVpnService.START)) }
    override fun onActivityResult(r:Int,result:Int,data:Intent?) { super.onActivityResult(r,result,data); if(r==7 && result==RESULT_OK) startCapture() }
    override fun onDestroy() { try { unregisterReceiver(receiver) } catch(_:Exception) {}; super.onDestroy() }
}
