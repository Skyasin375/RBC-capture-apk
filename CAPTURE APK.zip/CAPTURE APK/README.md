# RBC Network Capture (Android)

A native Kotlin Android Studio starter project implementing real packet capture through Android `VpnService`, live TCP/UDP header display, and classic PCAP output.

## Important limitation — read before running
This implementation is a **capture-only VPN**. It routes device traffic into its TUN interface and records raw IP packets, but it does not forward them to the internet. Therefore internet connectivity on this phone will pause while capture is active. Stop capture to restore normal connectivity. This is deliberately disclosed rather than pretending that a packet reader is a transparent VPN.

A production transparent capture app needs a correctly implemented TCP/UDP forwarding engine (for example a maintained tun2socks/userspace stack), IPv6/UDP handling, DNS behavior, reconnect logic and extensive device testing. Do not distribute this starter as a transparent full-network monitor.

## Build
1. Open this folder in Android Studio (current stable).
2. Allow Gradle sync; install Android SDK 35 if prompted.
3. Connect an Android device with USB debugging, or use an emulator.
4. Run the `app` configuration.
5. Tap **START CAPTURE** and approve Android's VPN permission dialog.
6. Stop capture to restore normal network connectivity.

## Output
PCAP files are written to:
`Android/data/com.rbc.networkcapture/files/output/`

Open the `.pcap` file in Wireshark. It uses classic PCAP with LINKTYPE_RAW (101), storing raw IPv4/IPv6 IP packets.

## Scope
- Real packet bytes read from the Android VPN TUN interface.
- IPv4/IPv6 address parsing.
- TCP/UDP protocol and port display.
- Live packet counters.
- PCAP file output.
- No TLS decryption, payload reconstruction, remote-device capture, or Wi-Fi promiscuous mode.
- Android VPN consent is required. Capture only traffic on devices/networks you own or are authorized to inspect.

## Build APK using only your Android phone (GitHub Actions)
This repository includes `.github/workflows/build-apk.yml`.
1. Create a GitHub account and a new repository in the GitHub mobile app or browser.
2. Upload the extracted project files to the repository (GitHub mobile web may require browser desktop mode for bulk upload).
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Run **Build RBC Network Capture APK** using **Run workflow** (or push to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `RBC-Network-Capture-debug`.
6. Extract the artifact ZIP on your phone and install `app-debug.apk`. Android may ask permission to install unknown apps.

The workflow builds the APK on GitHub's hosted runner; it does not make the app a fully transparent VPN. Current capture implementation is capture-only and pauses internet while active.
